import 'dart:convert';

import 'package:dio/dio.dart';

class NetConfig {
  static String baseUrl = 'https://deco3801-shakalakaboom.uqcloud.net/';

  static Future login(String email, String password) async {
    Response response;
    var dio = Dio();
    dio.options.baseUrl = baseUrl;
    dio.options.contentType ='application/x-www-form-urlencoded';
    response = await dio
        .post('login.php', data: {'email': email, 'password': password});
    if (response.statusCode == 200) {
      return response;
    } else {
      return null;
    }
  }

  static Future register(String email, String password, String username) async {
    Response response;
    var dio = Dio();
    dio.options.baseUrl = baseUrl;
    dio.options.contentType ='application/x-www-form-urlencoded';
    response = await dio
        .post('register.php',
        data: {'email': email, 'password': password, 'username': username});
  }

  static Future checkExist(String email) async {
    Response response;
    var dio = Dio();
    dio.options.baseUrl = baseUrl;
    dio.options.contentType ='application/x-www-form-urlencoded';
    response = await dio
        .post('checkexist.php', data: {'email': email});
    return response;
  }

}
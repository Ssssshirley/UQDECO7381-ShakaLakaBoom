import 'package:flutter/material.dart';

import 'Leaderboard.dart';
import 'Profile.dart';
import 'Track.dart';
import 'Activities.dart';


class Tabs extends StatefulWidget {
  final Map arguments;

  const Tabs({super.key, required this.arguments});


  @override
  _TabsState createState() => _TabsState();
}

class _TabsState extends State<Tabs> {

  int _currentIndex = 0;
  final List<Widget> _pages = const [
    TrackPage(),
    ActivitiesPage(),
    LeaderboardPage(),
    ProfilePage()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Go Eco"),
        automaticallyImplyLeading: false,
        backgroundColor: Colors.green,
        centerTitle: true,
        actions: [
          Text("Welcome! " + widget.arguments['username']),
          const SizedBox(width:10),
        ],
      ),
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        fixedColor: Colors.green,
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        onTap: (int index){
          setState(() {
            _currentIndex=index;
          });
        },
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.track_changes),
              label: "Track"
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.local_activity),
            label: "Activities",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: "Leaderboard",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.supervised_user_circle),
            label: "Profile",
          ),
        ],
      ),
    );
  }
}